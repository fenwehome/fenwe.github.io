{
    "author": "春风",
    "ua": "",
    "homeUrl": "https://www.lkvod.cc/",
    "dcVipFlag": "true",
    "pCfgJs": "https://www.lkvod.cc/static/js/playerconfig.js",
    "pCfgJsR": "MacPlayerConfig.player_list=([\\w\\W]*?),MacPlayerConfig.downer_list=",
    "dcShow2Vip": {},
    "dcPlayUrl": "true",
    "cateManual": {
        "电影": "1",
        "连续剧": "2",
        "动漫": "4",
        "综艺": "3"
    },
    "homeVodNode": "//div[@class='module-item']",
    "homeVodName": "//div[@class='module-item-pic']/a/@title",
    "homeVodId": "//div[@class='module-item-pic']/a/@href",
    "homeVodIdR": "/detail/(\\w+).html",
    "homeVodImg": "//img/@data-src",
    "homeVodImgR": "",
    "homeVodMark": "//div[contains(@class,'right')]/span/text()",
//   "cateUrl": "https://www.lkvod.cc/type/{cateId}-{catePg}.html",
    "cateUrl": "https://www.lkvod.cc/show/{cateId}-{area}-{by}------{catePg}---{year}.html",
    "cateVodNode": "//div[@class='module-item']",
    "cateVodName": "//div[@class='module-item-pic']/a/@title",
    "cateVodId": "//div[@class='module-item-pic']/a/@href",
    "cateVodIdR": "/detail/(\\w+).html",
    "cateVodImg": "//img/@data-src",
    "cateVodImgR": "",
    "cateVodMark": "//div[contains(@class,'right')]/span/text()",
    "dtUrl": "https://www.lkvod.cc/detail/{vid}.html",
    "dtNode": "//body",
    "dtName": "//h1[@class='page-title']/text()",
    "dtNameR": "",
    "dtImg": "//div[@class='video-cover']//img/@data-src",
    "dtImgR": "",
    "dtCate": "//div[@class='tag-link']/a[position()>1]/text()",
    "dtCateR": "",
    "dtYear": "//span[contains(text(), '年代')]/following-sibling::div/a/text()",
    "dtYearR": "",
    "dtArea": "//a[3][@class='tag-link']/text()",
    "dtAreaR": "",
    "dtDirector": "//span[contains(text(), '导演')]/following-sibling::div/a/text()",
    "dtDirectorR": "",
    "dtActor": "//span[contains(text(), '主演')]/following-sibling::div/a/text()",
    "dtActorR": "",
    "dtDesc": "//span[contains(text(), '剧情')]/following-sibling::div/p/text()",
    "dtDescR": "",
    "dtFromNode": "//div[@class='module-tab-item tab-item']/span",
    "dtFromName": "/text()",
    "dtFromNameR": "",
    "dtUrlNode": "//div[@class='sort-item']",
    "dtUrlSubNode": "/a",
    "dtUrlId": "@href",
    "dtUrlIdR": "/play/(\\S+).html",
    "dtUrlName": "/span/text()",
    "dtUrlNameR": "",
    "playUrl": "https://www.lkvod.cc/play/{playUrl}.html",
    "playUa": "",
    "searchUrl": "https://www.lkvod.cc/index.php/ajax/suggest?mid=1&wd={wd}&limit=10",
    "scVodNode": "json:list",
    "scVodName": "name",
    "scVodId": "id",
    "scVodIdR": "",
    "scVodImg": "pic",
    "scVodMark": "",
  "filter": {
    "1": [
      {
        "key": "cateId",
        "name": "类型",
        "value": [
          {"n": "全部","v": ""},
          {"n": "动作片","v": "6"},
          {"n": "喜剧片","v": "7"},
          {"n": "爱情片","v": "8"},
          {"n": "科幻片","v": "9"},
          {"n": "恐怖片","v": "10"},
          {"n": "剧情片","v": "11"},
          {"n": "战争片","v": "12"}
        ]
      },
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "大陆","v": "大陆"},
          {"n": "韩国","v": "韩国"},
          {"n": "香港","v": "香港"},
          {"n": "台湾","v": "台湾"},
          {"n": "日本","v": "日本"},
          {"n": "美国","v": "美国"},
          {"n": "泰国","v": "泰国"},
          {"n": "英国","v": "英国"},
          {"n": "印度","v": "印度"},
          {"n": "法国","v": "法国"},
          {"n": "意大利","v": "意大利"},
          {"n": "新加坡","v": "新加坡"},
          {"n": "其他","v": "其他"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ],
    "2": [
      {
        "key": "cateId",
        "name": "类型",
        "value": [
          {"n": "全部","v": ""},
          {"n": "国产剧","v": "13"},
          {"n": "港台剧","v": "14"},
          {"n": "日韩剧","v": "15"},
          {"n": "欧美剧","v": "16"},
          {"n": "其他剧","v": "20"}
        ]
      },
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "内地","v": "内地"},
          {"n": "韩国","v": "韩国"},
          {"n": "香港","v": "香港"},
          {"n": "台湾","v": "台湾"},
          {"n": "日本","v": "日本"},
          {"n": "美国","v": "美国"},
          {"n": "泰国","v": "泰国"},
          {"n": "英国","v": "英国"},
          {"n": "新加坡","v": "新加坡"},
          {"n": "其他","v": "其他"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ],
    "3": [
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "内地","v": "内地"},
          {"n": "港台","v": "港台"},
          {"n": "日韩","v": "日韩"},
          {"n": "欧美","v": "欧美"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ],
    "4": [
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "国产","v": "国产"},
          {"n": "日本","v": "日本"},
          {"n": "欧美","v": "欧美"},
          {"n": "其它","v": "其它"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ]
  }
}

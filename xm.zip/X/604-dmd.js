//www.dm55.cc
{
  "author":"takagen99",
  "ua": "",
  "homeUrl": "http://www.88dmw.com",
  "cateManual": {
    "新番连载": "1", 
    "完结日漫": "3",
    "热门国漫": "4",
    "剧场动漫": "16"
  },
  
// Home Summary ================================================  
  "homeVodNode": "//div[@class='cn2_l']/div[@class='c2_contact']/div[@class='c1_l_wap_contact']/ul/li",
  "homeVodName": "/a/@title",
  "homeVodId": "/a/@href",
  "homeVodIdR": "/detail/(\\w+).html",
  "homeVodImg": "/a/img/@src",
  "homeVodMark": "/p[@class='time']/font/text()",
  
// Category Summary ================================================  
  "cateUrl": "http://www.88dmw.com/vod-list-id-{cateId}-pg-{catePg}-order--by--class--year-{year}-letter--area--lang-.html",
  "cateVodNode": "//div[@class='list3_cn_box']/div[@class='cn_box2']",
  "cateVodName": "/div/div/a/@title",
  "cateVodId": "/div/div/a/@href",
  "cateVodIdR": "/detail/(\\w+).html",
  "cateVodImg": "/div/div/a/img/@src",
  "cateVodMark": "/ul[@class='list_20']/li[2]/span/font/text()",

// Category Details ================================================    
  "dtUrl": "http://www.88dmw.com/detail/{vid}.html",
  "dtNode": "//div[(@class='warp')]",
  "dtName": "//div[@class='info-title']/h1/text()",
  "dtImg": "//div[@class='info-box']/div[@class='o_list']/div[@class='o_big_img_bg_b']/img/@src",
  "dtCate": "//div[@class='o_r_contact']/ul/li[8]/label/font[1]/text()",
  "dtYear": "//div[@class='o_r_contact']/ul/li[6]/text()",
  "dtArea": "//div[@class='o_r_contact']/ul/li[4]/label/text()",
  "dtActor": "//div[@class='o_r_contact']/ul/li[3]/span/text()",  
  "dtMark": "//div[@class='o_r_contact']/ul/li[7]/label/font[1]/text()", 
  "dtDirector": "//div[@class='o_r_contact']/ul/li[2]/span/text()",
  "dtDesc": "",

// Playlist =====================================================     
//  "dtFromNode": "//div[contains(@class,'from-tabs')]/label[contains(text(),'线路') or contains(text(),'云')]",  
  "dtFromNode": "//div[contains(@class,'from-tabs')]/label",
  "dtFromName": "/text()",
  "dtFromNameR": "",
//  "dtUrlNode": "//div[contains(@class,'current-tab')]",
  "dtUrlNode": "//div[contains(@class,'tabs-list')]",
  "dtUrlSubNode": "/div/ul/li/a",
  "dtUrlId": "@href",
  "dtUrlIdR": "/play/(\\S+).html",
  "dtUrlName": "/text()",
  "playUrl": "http://www.88dmw.com/play/{playUrl}.html",
  "playUa": "",
  
// Search Results ================================================     
  "searchUrl": "http://www.88dmw.com/index.php?m=vod-search-wd-{wd}",
  "scVodNode": "//div[@class='list3_cn_box']/div[@class='cn_box2']",
  "scVodName": "/div/div/a/@title",
  "scVodId": "/div/div/a/@href",
  "scVodIdR": "/detail/(\\w+).html",
  "scVodImg": "/div/div/a/img/@src",
  "scVodMark": "/ul[@class='list_20']/li[2]/span/font/text()",
  
// Filters =======================================================
    "filter": {
      "1": [
        {
          "key": "year",
          "name": "年份",
          "value": [           
            {"n": "全部","v": ""},
            {"n": "2022","v": "2022"},
            {"n": "2021","v": "2021"},
            {"n": "2020","v": "2020"},
            {"n": "2019","v": "2019"},
            {"n": "2018","v": "2018"},
            {"n": "2017","v": "2017"},
            {"n": "2016","v": "2016"},
            {"n": "2015","v": "2015"},
            {"n": "2014","v": "2014"},
            {"n": "2013","v": "2013"},
            {"n": "2012","v": "2012"},
            {"n": "2011","v": "2011"},
            {"n": "2010","v": "2010"},
            {"n": "2009","v": "2009"},
            {"n": "2008","v": "2008"},
            {"n": "2007","v": "2007"},
            {"n": "2006","v": "2006"},
            {"n": "2005","v": "2005"},            
            {"n": "2004","v": "2004"}
          ]
        }
      ],      
      "3": [
        {
          "key": "year",
          "name": "年份",
          "value": [           
            {"n": "全部","v": ""},
            {"n": "2022","v": "2022"},              
            {"n": "2021","v": "2021"},
            {"n": "2020","v": "2020"},
            {"n": "2019","v": "2019"},
            {"n": "2018","v": "2018"},
            {"n": "2017","v": "2017"},
            {"n": "2016","v": "2016"},
            {"n": "2015","v": "2015"},
            {"n": "2014","v": "2014"},
            {"n": "2013","v": "2013"},
            {"n": "2012","v": "2012"},
            {"n": "2011","v": "2011"},
            {"n": "2010","v": "2010"},
            {"n": "2009","v": "2009"},
            {"n": "2008","v": "2008"},
            {"n": "2007","v": "2007"},
            {"n": "2006","v": "2006"},
            {"n": "2005","v": "2005"},            
            {"n": "2004","v": "2004"}
          ]
        }
      ],
      "4": [
        {
          "key": "year",
          "name": "年份",
          "value": [            
            {"n": "全部","v": ""},
            {"n": "2022","v": "2022"},              
            {"n": "2021","v": "2021"},
            {"n": "2020","v": "2020"},
            {"n": "2019","v": "2019"},
            {"n": "2018","v": "2018"},
            {"n": "2017","v": "2017"},
            {"n": "2016","v": "2016"},
            {"n": "2015","v": "2015"},
            {"n": "2014","v": "2014"},
            {"n": "2013","v": "2013"},
            {"n": "2012","v": "2012"},
            {"n": "2011","v": "2011"},
            {"n": "2010","v": "2010"},
            {"n": "2009","v": "2009"},
            {"n": "2008","v": "2008"},
            {"n": "2007","v": "2007"},
            {"n": "2006","v": "2006"},
            {"n": "2005","v": "2005"},            
            {"n": "2004","v": "2004"}
          ]
        }
      ],
      "16": [
        {
          "key": "year",
          "name": "年份",
          "value": [        
            {"n": "全部","v": ""},
            {"n": "2022","v": "2022"},              
            {"n": "2021","v": "2021"},
            {"n": "2020","v": "2020"},
            {"n": "2019","v": "2019"},
            {"n": "2018","v": "2018"},
            {"n": "2017","v": "2017"},
            {"n": "2016","v": "2016"},
            {"n": "2015","v": "2015"},
            {"n": "2014","v": "2014"},
            {"n": "2013","v": "2013"},
            {"n": "2012","v": "2012"},
            {"n": "2011","v": "2011"},
            {"n": "2010","v": "2010"},
            {"n": "2009","v": "2009"},
            {"n": "2008","v": "2008"},
            {"n": "2007","v": "2007"},
            {"n": "2006","v": "2006"},
            {"n": "2005","v": "2005"},            
            {"n": "2004","v": "2004"}
          ]
        }
      ]
    }
  
}
